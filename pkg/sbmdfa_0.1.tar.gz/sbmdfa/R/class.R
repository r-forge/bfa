#' Upper triangular loadings restriction
#'
#' Returns the restriction matrix corresponding to Geweke & Zhou (1996)
#' upper-triangular positive diagonal condition
#' '
#' @param p number of rows (variables)
#' @param k number of columns (factors)
#' @return p by k matrix
#' @export

utri_restrict = function(p, k) {
  out = matrix(1, nrow=p, ncol=k)
  out[upper.tri(out)] = 0
  diag(out) = 2
  return(out)
}

#' Initialize a bfa model
#'
#' This function accepts a data matrix \code{D} and specified options,
#' returning an S3 object of class sbfac.
#'
#' @param D a numeric matrix where rows are variables and columns are observations
#' @param num.factor number of factors
#' @param loadings.restrict A PxK matrix whose entries give the restrictions
#' on the loadings matrix. Acceptable values are 0 (identically 0), 1 (unrestricted), 
#' or 2 (strictly positive)
#' @param priors A list of prior parameters: rhoa, rhob are the parameters of the 
#' beta prior on rho. s is the prior precision for factor loadings
#' @param obslabel a character vector of labels for each observation
#' @param varlabel a character vector of labels for each variable
#' @param ... ignored
#' @return An S3 object of class \code{sbfac}, which is a list. The elements
#' ldata, loadings, scores and rho are initialized values of model parameters. By default
#' these are randomly initialized; you can overwrite them if desired.
#' @export


bfa_model <- function(D, num.factor=1, loadings.restrict = NA,
                          priors = list(rhoa=1.0, rhob=1.0, s=1.0, taua=1.0, taub=1.0, s2a=1.0, s2b=1.0), 
                          obslabel=colnames(D), varlabel=rownames(D), 
                          ...) {
  
  D = as.matrix(D)
	D[is.infinite(D)] = NA
	p = dim(D)[1]
	n = dim(D)[2]
  k = num.factor
# 	Ra<-NULL
# 	argsorts <- NULL
# 	for (i in 1:p) {
# 		Ra<-rbind(Ra, match(D[i,],sort(unique(D[i,]))))
# 	}
# 	Ra[is.na(Ra)] = 0
#   
#   # Zero indexing for Rcpp
# 	Ra = Ra - 1 
# 	#argsorts = t(apply(Ra, 1, order))-1
#   
#   argsorts = matrix(0, nrow=p, ncol=n)
#   for (i in 1:p) {
#     levs = sort(unique(D[i,]))
#     asrow = which(is.na(D[i,]))
#     for (lev in levs) {
#       asrow = c(asrow, which(D[i,]==lev))
#     }
#     argsorts[i,] = asrow
#   }
#   
  U = D
  argsorts = matrix(0, nrow=p, ncol=n)
  Ra =  matrix(0, nrow=p, ncol=n)
  for (i in 1:p) {
    levs = sort(unique(D[i,]))
    asrow = which(is.na(D[i,]))
    rarow = rep(0, length(asrow))
    
    for (j in 1:length(levs)) {
      lev = levs[j]
      inds = which(D[i,]==lev)
      asrow = c(asrow, inds)
      Ra[i,inds] = rep(j, length(inds))
    }
    argsorts[i,] = asrow
    
    df = ecdf(D[i,])
    nobs = n - sum(is.na(D[i,]))
    U[i,] = df(D[i,])*nobs/(nobs+1)
  }
    
  argsorts = argsorts - 1 
  Ra = Ra - 1
  
	#ecdf.ct <- apply(D,1,rank,ties.method="max",na.last="keep")
	#num.not.na = apply(!is.na(D),1,sum)
	#U <- t(ecdf.ct)/(num.not.na+1)
	Z = qnorm(U)*sqrt(k)

	maxes = matrix(rep(0, p*n), nrow=p)
	L = 0
	for (i in 1:p) {
		m = sort(unique(Z[i,]))#[-length(m)], 99999.0)
    m[length(m)] = 99999.0
		maxes[i,1:length(m)] = m
		L = max(L, length(m))
	}
	
	maxes = maxes[,1:L]

  Z[is.na(Z)] = rnorm(length(Z[is.na(Z)]))
  
  
  scores = matrix(rnorm(k*n), nrow=k)
  loadings = matrix(rnorm(k*p), nrow=p)
     
  if (any(is.na(loadings.restrict))) loadings.restrict = utri_restrict(p,k)
  
  for (i in 1:p) {
    for (j in 1:k) {
      if (loadings.restrict[i,j]==1) {
        loadings[i,j] = mean(Z[i,])/sd(Z[i,])
      } else {
        loadings[i,j] = loadings.restrict[i,j]
      }
    }
  }
  bfa:::.updateScores(Z, loadings, scores)
 
  
 #.updateSparseLoadings <- function (Z_, A_, F_, tauinv_, rho_, A_restrict_, pnz_) 
#   lrtmp = utri_restrict(p,k)
#   diag(lrtmp) = 1
#   loadm = matrix(0,nrow=p, ncol=k)
#   scorm = matrix(0,nrow=k, ncol=n)
#   for (i in 1:(p*10)) {
#       bfa:::.updateSparseLoadings(Z, loadings, scores, 
#                                     as.matrix(rep(1.0,p)), as.matrix(rep(0.999,p)), 
#                                     lrtmp, 
#                                     matrix(1, nrow=p, ncol=k))
#       bfa:::.updateScores(Z, loadings, scores)
#       if (i>(p*5)) {
#         loadm = loadm+loadings
#         scorm = scorm+scores
#       }
#   }
  
  #bfa:::.updateZcut(Z, Ra, maxes, argsorts, matrix(0,nrow=p, ncol=k), 
  #                    matrix(0,nrow=k, ncol=n))
#   
#   if (all(loadings.restrict==utri_restrict(p,k))) {
#   	s = sign(diag(loadm))
#   	loadings = loadm %*%diag(s, k)/(p*5)
#   	scores = s*scores/(p*5)
#   }
#   
	out = list(data=D, ldata=Z, ranks=Ra, maxes=maxes, 	
				argsorts=argsorts, P = dim(D)[1], N = dim(D)[2], K=num.factor,
				obslabel=obslabel, varlabel=varlabel,
				nsim=0, nburn=0, thin=1, 
        
        loadings = loadings,
        post.loadings.mean = matrix(rep(0,k*p), ncol=k), 
        post.loadings.var  = matrix(rep(0,k*p), ncol=k),
        
        scores = scores,
        post.scores.mean = matrix(rep(0,k*n), nrow=k),
        post.scores.var  = matrix(rep(0,k*n), nrow=k),
        
        tauinv = rgamma(p, 1), 
        rho = rbeta(k, priors$rhoa, priors$rhob),
        priors = priors,
        
        loadings.restrict = loadings.restrict
        )
  
	class(out) = "bfa"
  return(out)
}

#' Print method for bfa object
#' @param x An bfa object
#' @param ... Ignored
#' @method print bfa

print.bfa <- function(x, ...) {
	cat("bfa model object\n")
	cat("Use mean() or var() to get parameter estimates\n")
	}

#' Extract posterior means from bfa object
#' @param x An bfa object
#' @param ... Ignored
#' @return A list with elements loadings and scores containing MCMC means
#' @method mean bfa
mean.bfa <- function(x, ...) {
  return(list(loadings=x$post.loadings.mean, scores=x$post.scores.mean))
}

#' Extract posterior variances from sbfac object
#' @param x An sbfac object
#' @param ... Ignored
#' @method var bfa
#' @return A list with elements loadings and scores containing MCMC variances
var.bfa <- function(x, ...) {
  return(list(loadings=x$post.loadings.var, scores=x$post.scores.var))
}

