#' @nord
.updateScores <- function (Z_, A_, F_) 
.Call("updateScoresC", Z_, A_, F_, PACKAGE = "bfa")

#' @nord
 .updateRho <- function (rho_, A_, rhoa_, rhob_) 
.Call("updateRho", rho_, A_, rhoa_, rhob_, PACKAGE = "bfa")

#' @nord
#.updateSparseLoadingsJ( SEXP Z_, SEXP A_, SEXP F_, SEXP tauinv_, SEXP rho_, SEXP A_restrict_, SEXP pnz_ )
 .updateSparseLoadings <- function (Z_, A_, F_, tauinv_, rho_, A_restrict_, pnz_) 
.Call("updateSparseLoadingsJ", Z_, A_, F_, tauinv_, rho_, A_restrict_, pnz_, PACKAGE = "bfa")

#SEXP updateZ( SEXP Z_, SEXP Ra_, SEXP maxes_, SEXP argsorts_, SEXP A_, SEXP F_ ){

#' @nord
 .updateZ <- function (Z_, Ra_, maxes_, argsorts_, A_, F_) {
.Call("updateZ", Z_, Ra_, maxes_, argsorts_, A_, F_,  PACKAGE = "bfa")
return()
}

#' @nord
.updateZcut <- function (Z_, Ra_, maxes_, argsorts_, A_, F_) {
.Call("updateZcut", Z_, Ra_, maxes_, argsorts_, A_, F_,  PACKAGE = "bfa")
return()
}

#' @nord
#SEXP MCMCstep( SEXP Z_, SEXP A_, SEXP F_, SEXP tauinv_, SEXP rho_ , SEXP Ra_, SEXP maxes_, SEXP argsorts_, SEXP priors_, SEXP nsim_, SEXP nburn_, SEXP thin_)
.MCMCstep <- function (Z_, A_, F_, tauinv_, rho_, Ra_, maxes_, argsorts_, A_restrict_, priors_, nsim_, nburn_, thin_, printstatus_, keep.scores, keep.loadings, more_args)
.Call("MCMCstep", Z_, A_, F_, tauinv_, rho_, Ra_, maxes_, argsorts_, A_restrict_, priors_, nsim_, nburn_, thin_, printstatus_, keep.scores, keep.loadings, more_args, PACKAGE = "bfa")

#' Perform MCMC model fitting for an bfa model
#'
#' This function performs a specified number of MCMC iterations and
#' returns an object containing summary statistics from the MCMC samples
#' as well as the actual samples if keep.scores or keep.loadings are TRUE.
#' Default behavior is to save only the loadings. It is recommended to examine
#' traces and marginal posterior density estimates for the loadings as these can be highly skewed
#' and/or multimodal so that the mean/variance are poor summaries. The scores are generally
#' more 'normal'-looking. 
#' '
#' @param model an object of type bfa, as returned by bfa(data)
#' @param nsim number of iterations past burn-in
#' @param nburn number of initial (burn-in) iterations to discard
#' @param thin keep every thin'th MCMC sample (i.e. save nsim/thin samples)
#' @param print.status how often to print status messages to console
#' @param keep.scores save samples of factor scores
#' @param keep.loadings save samples of factor loadings
#' @param loading.prior Specify point mass ("pointmass", default) or normal priors ("normal") 
#' @param coda create \code{mcmc} objects to allow use of functions from the 
#' \code{coda} package: "all" for loadings and scores, "loadings" or "scores" for one or the
#' other, or "none" for neither
#' @param coda.scale put the loadings on the correlation scale when creating \code{mcmc} objects
#' @param ... additional (experimental) arguments
#' @return The S3 \code{bfa} object \code{model}, now with posterior samples/summaries.
#' @export

fit_bfa <- function(model, nsim, nburn, thin=1, print.status=500,
                   keep.scores=FALSE, keep.loadings=TRUE, loading.prior="pointmass",
                   coda="loadings", coda.scale=TRUE,  ...) {
  more_args = list(...)
  if (is.null(more_args$init)) more_args$init=TRUE
  
  if (model$nsim == 0 && more_args$init==TRUE && more_args$px>0) {
    model = .fit(model, max(1000, nburn/10), 0, thin=1, print.status=max(1000, nburn/2)+1,
                   keep.scores=FALSE, keep.loadings=FALSE, loading.prior=loading.prior,
                   coda="none", save_max=0, px=0, more_args$error_var_i, quiet=TRUE )
  }
  
  model = .fit(model, nsim, nburn, thin=thin, print.status=print.status,
                   keep.scores=keep.scores, keep.loadings=keep.loadings, loading.prior=loading.prior,
                   coda=coda, coda.scale=coda.scale,  ...)
  
}

########################################################
# Actual model fitting fcn
########################################################

.fit <- function(model, nsim, nburn, thin=1, print.status=500,
                   keep.scores=FALSE, keep.loadings=TRUE, loading.prior="pointmass",
                   coda="loadings", coda.scale=TRUE,  ...) {
      
  K = model$K; P = model$P; N = model$N
  
  more_args = list(...)
 
  
  if (loading.prior=="pointmass")  more_args$method = 1
  if (loading.prior=="gdp")        more_args$method = 2
  if (loading.prior=="normal")     more_args$method = 0
  
  if (any(is.null(more_args$error_var_i))) more_args$error_var_i = matrix(rep(0.0, P))
  
  if (any(more_args$error_var_i != matrix(rep(0.0, P)))) {
    cts = which(more_args$error_var_i>0)
    model$ldata[cts,] = model$data[cts,]
  }
  

	model$nsim = nsim
	model$nburn = nburn
	model$thin = thin
	sim = .MCMCstep(model$ldata, model$loadings, model$scores, model$tauinv, 
		 model$rho, model$ranks, model$maxes, model$argsorts, model$loadings.restrict,
		 model$priors, nsim, nburn, thin, print.status, keep.scores, keep.loadings, more_args)
  
  
	
  if (keep.scores)   dim(sim$Fp)=c(K,N,nsim/thin)
  if (keep.loadings) dim(sim$Ap)=c(P,K,nsim/thin)
  if (more_args$save_max>0) dim(sim$maxp) = c(dim(model$maxes), nsim/thin)	
 
  dim(sim$Fp.mean) = c(K,N)
  dim(sim$Fp.var)  = c(K,N)
  dim(sim$Ap.mean) = c(P,K)
  dim(sim$Ap.var)  = c(P,K)
  dim(sim$pnz)     = c(P,K)
	
  model$post.loadings.mean = sim$Ap.mean
  model$post.loadings.var  = sim$Ap.var
  model$post.loadings      = sim$Ap
	
  model$post.scores.mean   = sim$Fp.mean
  model$post.scores.var    = sim$Fp.var
  model$post.scores        = sim$Fp
  
  model$post.sigma2        = 1/sim$sigma2inv
  model$post.loadings.prob = 1.0-sim$pnz
  
 if (more_args$save_max>0) {
    model$cutpoints.mean = sim$maxmean
    model$cutpoints.var  = sim$maxvar
    model$post.cutpoints = sim$maxp
    
    dim(model$cutpoints.mean) = dim(model$maxes)
    dim(model$cutpoints.var)  = dim(model$maxes)
 }
 
  if (coda!="none") {
    if (coda=="all") {
      model$loadings.mcmc = get_coda(model, loadings=TRUE, scores=FALSE, scale=coda.scale)
      model$scores.mcmc   = get_coda(model, loadings=FALSE, scores=TRUE)
    } else if (coda=="loadings") {
      model$loadings.mcmc = get_coda(model, loadings=TRUE, scores=FALSE, scale=coda.scale)
    } else if (coda=="scores") {
      model$scores.mcmc   = get_coda(model, loadings=FALSE, scores=TRUE)
    }
  }

  return(model)
}


#' Imputation on the original scale of the data
#'
#' This function imputes data on the original scale given a current value of the latent
#' continuous data, using the empirical cdf.
#'
#' @param D Observed data
#' @param Z Latent data (standardized)
#' @return A vector of length \code{length(D[is.na(D)])} containing the
#' imputed values
#' @export


#impute <- function(D, Z) {
#  out = NA
#  for (i in 1:dim(D)[1]) {
#    im = quantile(D[i,], pnorm(Z[i,is.na(Z[i,]), type=1, na.rm=TRUE)
#    out = c(out, im)
#  }
#}



