#' Semiparametric Bayesian Mixed Data Factor Analysis
#' 
#' \tabular{ll}{
#' Package: \tab bfa\cr
#' Type: \tab Package\cr
#' Version: \tab 1.0\cr
#' Date: \tab 2011-06-03\cr
#' License: \tab GPL-3\cr
#' LazyLoad: \tab yes\cr
#' }
#'
#' This package provides MCMC model fitting for semiparametric Bayesian
#'  mixed data factor analysis, an analogue of traditional factor analysis where
#'  inference is based on the (unobserved) correlation matrix of a Gaussian copula
#'  instead of the covariance or correlation matrix of the data itself. It handles
#'  ordinal data that is discrete or continuous using an approximate rank-based
#'  likelihood.
#' 
#' @name bfa-package
#' @aliases bfa
#' @docType package
#' @title Semiparametric Bayesian Mixed Data Factor Analysis
#' @author Jared Murray \email{jared.murray@@stat.duke.edu}
#' @keywords package
#' @useDynLib bfa
# @references
# \url{url}

NULL