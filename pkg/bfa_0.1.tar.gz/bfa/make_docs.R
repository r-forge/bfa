library(roxygen)
setwd('~/Documents/software/')
roxygenize('bfa', 'bfa', 
           copy.package=FALSE, overwrite=TRUE, unlink.target=FALSE, use.Rd2=TRUE)
