#ifndef _bfa_imh_h
#define _bfa_imh_h

#include <RcppArmadillo.h>
#include <Rcpp.h>
#include "bfa_common.h"

void sampleZ_cut( Rcpp::NumericMatrix& Z , Rcpp::IntegerMatrix& Ra, 
			 Rcpp::NumericMatrix& maxes, Rcpp::IntegerMatrix& argsorts, 
			 arma::mat& mu, int row=-1);

double likrat( Rcpp::NumericMatrix& Z , Rcpp::IntegerMatrix& Ra, 
			   arma::vec& current, arma::vec& propose,
			   Rcpp::IntegerMatrix& argsorts, arma::mat& A, arma::mat& F, int row, int le);
			   
//SEXP updateZ( SEXP Z_, SEXP Ra_, SEXP maxes_, SEXP argsorts_, SEXP A_, SEXP F_ );
RcppExport SEXP updateZcut( SEXP Z_, SEXP Ra_, SEXP maxes_, SEXP argsorts_, SEXP A_, SEXP F_ );

#endif
