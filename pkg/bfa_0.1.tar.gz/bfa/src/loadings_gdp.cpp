#include "loadings_gdp.h"
#include "bfa_common.h"
//#include <RcppArmadillo.h>
//#include <Rcpp.h>

using namespace arma ;
using namespace Rcpp ;


void sampleLoadingsGDP(arma::mat& Z, arma::mat& A, arma::mat& F, Rcpp::NumericVector& sigma2inv,
					Rcpp::NumericVector& error_var_i,
					arma::mat& A_restrict, arma::mat& A_prior_var, double alpha, double beta,
					int px, int n, int p, int k ){
    
    arma::mat Lam = arma::zeros(p,k);
    //sample lambda, top level mixing param
    for (int i=0; i<p; i++) {
      for (int j=0; j<k; j++) {
        if (i < j) {
          Lam(i,j) = 0.0;
        } else {
          Lam(i,j) = Rf_rgamma(alpha + 1, beta + fabs(A(i,j)));
        }
      }
    }
    
    arma::mat Psi_inv = arma::zeros(p,k);
    //sample Psi inverse, lower level mixing param
    for (int i=0; i<p; i++) {
      for (int j=0; j<k; j++) {
        if (i < j) {
          Psi_inv(i,j) = 0.0;
        } else {
          double mu = fabs(A(i,j)*sqrt(Lam(i,j)));
          Psi_inv(i,j) = rinvgauss(mu, Lam(i,j)*Lam(i,j));
        }
      }
    }
    
    arma::mat FFt = F*arma::trans(F);
    int num_prior_var = A_prior_var.n_rows;
    double r = 1.0;
    
    arma::mat Ap_var;
    arma::mat Ap_means;
    arma::mat Rf;
    arma::mat Apriorv;
    
    if (num_prior_var == 1) {
    	Apriorv = diagmat(A_prior_var.row(0));
    	Ap_var = inv(FFt + inv(Apriorv));
    	Ap_means = Ap_var*F*trans(Z);
    	Rf = arma::chol(Ap_var);
    }
    
    //Rprintf("\n\nSet initial params!\n");
    arma::colvec num_res = arma::sum(A_restrict, 1);

    for (int j=0; j<p; j++) {
		if (j<k) {
			//uvec unres_index = arma::find(A_restrict.row(j) > 0);
			// only uses upper triangular condition for now
			arma::mat Ap_var_sm = inv( FFt(span(0,j), span(0,j))*sigma2inv(j)  
			                           + diagmat(Psi_inv(j, span(0,j))));
			                           
			                           
			arma::vec Ap_mean_sm = Ap_var_sm * F(span(0,j),span::all)*trans(Z.row(j))*sigma2inv(j);
			arma::mat U = arma::randn(j+1, 1);
			arma::mat R = arma::chol(Ap_var_sm);
			
			arma::vec draw =  R*U + Ap_mean_sm;
			
			int maxprop = 1e8;
					
			bool good = false;
			for (int ii=0; ii<maxprop; ii++) {
				R_CheckUserInterrupt();
				if (draw(j)>0) {
					good = true;
					break;
				} else {
				  U = arma::randn(j+1, 1);
					draw =  R*U + Ap_mean_sm;
				}
			}
			
			if (!good) {
				Rprintf("loadings draw failed\n");
			}
			
			
			
			//A(j,j) = arma::as_scalar(draw);
			if (px>0 && error_var_i(j)<1.0) {
				double ssq = accu(square(trans(Z.row(j)) - trans(F)*Ap_means.col(j)));
				double prior_ssq = as_scalar(trans(Ap_means.col(j)) * diagmat(A_prior_var.row(0)) * Ap_means.col(j));
				double scale = 2.0/(ssq + prior_ssq);
				r = Rf_rgamma(0.5*n, scale);
			} else {
				r = 1.0;
			}
			for (int i=0; i<j+1; i++) {
				A(j,i) = sqrt(r)*draw(i);
			}
		} else {
			//unrestricted rows
			
    	Ap_var = inv(FFt*sigma2inv(j) + diagmat(Psi_inv.row(j)));
    	Ap_means = Ap_var*F*trans(Z)*sigma2inv(j);
    	Rf = arma::chol(Ap_var);
			
			
			arma::mat U = arma::randn(k, 1);
			arma::vec draw = Rf*U + Ap_means.col(j);
			if (px>0 && error_var_i(j)<1.0) {
				double ssq = accu(square(trans(Z.row(j)) - trans(F)*Ap_means.col(j)));
				double prior_ssq = as_scalar(trans(Ap_means.col(j)) * diagmat(A_prior_var.row(0)) * Ap_means.col(j));
				double scale = 2.0/(ssq + prior_ssq);
				r = Rf_rgamma(0.5*n, scale);
			} else {
				r = 1.0;
			}
			for (int i=0; i<k; i++) {
				A(j,i) = sqrt(r)*draw(i);
			}
		}
  }
}

