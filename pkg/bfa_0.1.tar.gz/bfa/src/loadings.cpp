#include <float.h>
#include "loadings.h"
#include "bfa_common.h"
//#include <RcppArmadillo.h>
//#include <Rcpp.h>

using namespace arma ;
using namespace Rcpp ;


void sampleLoadings(arma::mat& Z, arma::mat& A, arma::mat& F, Rcpp::NumericVector& sigma2inv,
					Rcpp::NumericVector& error_var_i,
					arma::mat& A_restrict, arma::mat& A_prior_var, 
					int px, int n, int p, int k, bool positive){
	//sampleLoadings(Z, A, F, A_restrict, A_prior_var, px, n, p, k);
    arma::mat FFt = F*trans(F);
    
    //arma::vec eigval;
  	//arma::mat eigvec;
  	//arma::eig_sym(eigval, eigvec, FFt);
    
    int num_prior_var = A_prior_var.n_rows;
    double r = 1.0;
    double u, v, lo, un, samp;
    arma::mat Ap_var;
    arma::mat Ap_means;
    arma::mat Rf;
    arma::mat Apriorv;
    arma::mat tt;
    
    if (px > 0) {
    	Apriorv = diagmat(A_prior_var.row(0));
    	Ap_var = inv(FFt + inv(Apriorv));
    	Ap_means = Ap_var*F*trans(Z);
    	Rf = arma::chol(Ap_var);
    }
    
    //Rprintf("\n\nSet initial params!\n");
    arma::colvec num_res = arma::sum(A_restrict, 1);
    
    arma::vec sumf2 = arma::sum(arma::pow(F, 2), 1);
    double tauinv = 1.0;
    
    for (int j=0; j<p; j++) {
		if (j < k) {
			//uvec unres_index = arma::find(A_restrict.row(j) > 0);
			// only uses upper triangular condition for now
			arma::mat Ap_var_sm = inv(FFt(span(0,j), span(0,j))*sigma2inv(j) + inv(diagmat(A_prior_var(0, span(0,j)))));
			arma::vec Ap_mean_sm = Ap_var_sm * F(span(0,j),span::all)*trans(Z.row(j))*sigma2inv(j);
			arma::mat U = arma::randn(j+1, 1);
			arma::mat R = arma::chol(Ap_var_sm);
			
			if (px>0 && error_var_i(j)<1.0) {
				double ssq = accu(square(trans(Z.row(j)) - trans(F)*Ap_means.col(j)));
				double prior_ssq = as_scalar(trans(Ap_means.col(j)) * inv(diagmat(A_prior_var.row(0))) * Ap_means.col(j));
				double scale = 2.0/(ssq + prior_ssq);
				r = Rf_rgamma(0.5*n, scale);
			} else {
				r = 1.0;
			}
			
			arma::vec draw =  R*U + sqrt(r)*Ap_mean_sm;
			
			for (int i=0; i<j; i++) {
				A(j,i) = draw(i);
			}
			
			if (positive) {
				//Draws A(jj)|A(ij) for i<j; univariate TN vs MVTN
					//t = Z.row(i) - A.row(i)*F + A(i,j)*F.row(j);
					//u = arma::accu(F.row(j)%t)*sqrt(r)*sigma2inv(j);
					//v = sumf2(j)*sigma2inv(j) + tauinv[i];
				tt = Z.row(j) - A.row(j)*F + A(j,j)*F.row(j);
				u = arma::accu(F.row(j)%tt)*sigma2inv(j)*sqrt(r);
				v = sumf2(j)*sigma2inv(j) + tauinv;
				lo = Rcpp::stats::pnorm_1( -u/(sqrt(v)), 0.0, true, false);
				un = std::min(Rf_runif(lo, 1.0), 1.0-6.7e-16);
				samp = u/v + Rcpp::stats::qnorm_1(un, 0.0, true, false)/sqrt(v);
			}
			A(j,j) = positive ? samp : draw(j);
			
		} else {
			//unrestricted rows
			
			Apriorv = diagmat(A_prior_var.row(0));
    	Ap_var = inv(FFt*sigma2inv(j) + inv(Apriorv));
    	Ap_means = Ap_var*F*trans(Z)*sigma2inv(j);
    	Rf = arma::chol(Ap_var);
			
			
			arma::mat U = arma::randn(k, 1);
			arma::vec draw = Rf*U + Ap_means.col(j);
			if (px>0 && error_var_i(j)<1.0) {
				double ssq = accu(square(trans(Z.row(j)) - trans(F)*Ap_means.col(j)));
				//double ssq = accu(square(Z.row(j)));
				double prior_ssq = as_scalar(trans(Ap_means.col(j)) * inv(diagmat(A_prior_var.row(0))) * Ap_means.col(j));
				//double prior_ssq = -1.0*as_scalar( Z.row(j)*trans(F)*Ap_var*F*trans(Z.row(j)) );
				double scale = 2.0/(ssq + prior_ssq);
				r = Rf_rgamma(0.5*n, scale);
				
				//Rprintf("Diff: %f\n\n", ssq-ssq0 + prior_ssq-prior_ssq0);
			} else {
				r = 1.0;
			}
			//	Rprintf("r: %f\n\n", r);
			for (int i=0; i<k; i++) {
				A(j,i) = sqrt(r)*draw(i);
			}
		}
  }
}

